# BitBoost - Sever Booster
Tool that joins nitro tokens to servers and boosts them automatically...

**Previous patched Version: https://github.com/DaniEnsi/discord-server-boost-tool**

## Improvements
- Improved general speed of token switching
- Added automatic server joining (No Captcha support yet)
- Improved UI

# Achievements
- 20 Stars - Add hCaptcha support
- 50 Stars - Release Version 3

# How to use
1. Run ```setup.bat```
2. Paste your tokens into ```tokens.txt```
3. Run ```BitBoost.py```

If you have any issues create one or DM me on discord

## Information 

![image](https://user-images.githubusercontent.com/74594229/184509377-b16c89e1-ae09-45f9-b034-8048b4229500.png)


Educational purposes only
